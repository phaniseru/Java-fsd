package com.CollectionsMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class MapDemo {
public static void main(String[] args) {
	HashMap<Integer,Integer> m= new HashMap<Integer,Integer>();
	m.put(2, 3);
	m.put(4, 3);
	m.put(5, 3);
	m.put(27, 3);
	m.put(50, 3);
	System.out.println(m);
	System.out.println(m.get(5));
	System.out.println(m.remove(5));
	System.out.println("Size "+m.size());
	//LinkedHash Maps
	LinkedHashMap<Integer,Integer> lhm=new LinkedHashMap<Integer,Integer>();
	lhm.put(1, 3);
	lhm.put(2, 3);
	lhm.put(3, 3);
	lhm.put(4, 3);
	lhm.put(5, 3);
	System.out.println(lhm);
	System.out.println(lhm.size());
	//Tree Map
	TreeMap<Integer,Integer> tm=new TreeMap<Integer,Integer>();
	tm.put(1, 3);
	tm.put(2, 3);
	tm.put(3, 3);
	tm.put(4, 3);
	tm.put(5, 3);
	System.out.println(tm);
	System.out.println(tm.size());
	
	
	
}

}
