package com.FileHandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FilesDemo {
public static void main(String[] args) {
	//File creation 
	File f = new File("C:\\FilesDemo");
	f.mkdir();
	File f1 = new File("C:\\FilesDemo","Welcome2.txt");
	System.out.println(f1.exists());
	try {
		f1.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(f.exists());
	
	//Writing data to file
	try {
		
		FileWriter fw = new FileWriter("Welcome2.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("Welcome to java File Handling Concepts");
		bw.write("From XYZ youtube channel");
		System.out.println("Writing ......");
		bw.flush();
		bw.close();
		System.out.println("writing Completed");
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//Reading data from file
	System.out.println("Reading data from file");
	try {
		FileReader fr = new FileReader("Welcome2.txt");
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		while(line!=null)
		{
			System.out.println(line);
			line=br.readLine();
		}
		br.close();
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	boolean b=f1.delete();
	if(b)
	{
		System.out.println("File Deleted Successfully");
	}
	else
	{
		System.out.println("File not Deleted ");
	}
	
	
	
	
}
}