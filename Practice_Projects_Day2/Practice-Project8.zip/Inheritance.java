package com.oops;

import java.util.Scanner;

/*Pillars of Oops
 * 1.Inheritance:-acquiring the properties of parent
 * 2.PolyMorphism:-having many forms
 * 3.Abstraction:-Data hiding
 * 4.Encapsulation:-Binding of data members is known as Encapsulation*/
//Inheritance Demo
class InheritanceDemo
{
	String name;
	public InheritanceDemo(String name)
	{
		this.name=name;
	}
	void display()
	{
		System.out.println(name);
	}
	void generateId()
	{
		String id = name.substring(1, 2)+"1245"+name.substring(3, 5);
		System.out.println(id);
	}
}
public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the full name:");
		InheritanceDemo i = new InheritanceDemo(s.next());
		i.display();
		i.generateId();
		s.close();
		
		
	}

}