
	package com.oops;

	import java.util.Scanner;

	public class Encapsulation {
		int a;
		int b;
		public void add(int a,int b)
		{
			System.out.println("Addition is : "+(a+b));
		}
		public int sub(int a,int b)
		{
			return a+b;
		}
		public void mul(int a,int b)
		{
			System.out.println("Addition is : "+(a*b));
		}
		public float div(int a,int b)
		{
			return a/b;
		}
		public static void add1(int a,int b)
		{
			System.out.println("Addition is : "+(a+b));
		}
		public static  int sub1(int a,int b)
		{
			return a+b;
		}
		public static void mul1(int a,int b)
		{
			System.out.println("Addition is : "+(a*b));
		}
		public static float div1(int a,int b)
		{
			return a/b;
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner s = new Scanner(System.in);
			Encapsulation d = new Encapsulation();
			d.a=s.nextInt();
			d.b=s.nextInt();
			d.add(d.a, d.b);
			Encapsulation.add1(d.a, d.b);
			System.out.println(d.sub(d.a,d.b));

		}

	}
