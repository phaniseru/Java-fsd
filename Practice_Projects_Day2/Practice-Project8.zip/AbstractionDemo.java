package com.oops;

import java.util.Scanner;

abstract class Abstraction
{
	private String username;
	private String mobilenumber;
	public Abstraction(String username,String mobilenumber)
	{
		this.username=username;
		this.mobilenumber=mobilenumber;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getmobilenumber() {
		return mobilenumber;
	}
	public void setmobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public abstract void idGenerator();
	
}
public class AbstractionDemo extends Abstraction {
	public AbstractionDemo(String username,String mobilenumber)
	{
		super(username,mobilenumber);
	}
	public void idGenerator()
	{
		System.out.println("Default password : "+getUsername().substring(0,3)+getmobilenumber().substring(0,3));
	}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the user name");
	String username=s.nextLine();
	System.out.println("Enter the mobile number");
	String mobilenumber = s.nextLine();
	AbstractionDemo a = new AbstractionDemo(username,mobilenumber);
	
	System.out.println(a.getUsername());
	System.out.println(a.getmobilenumber());
	System.out.println();
	a.idGenerator();
	s.close();
	
}
}