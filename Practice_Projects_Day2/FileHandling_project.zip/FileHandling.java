package com.filehandlingLMS;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandling {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		//creation of director
		/*File f = new File("C:\\FileHandlingDemo");
		if(f.mkdir())
		{
			System.out.println("Directory Created");
		}
		else
		{
			System.out.println("Directory is not Created");
		}*/
		//creation of file
		FileWriter fw = new FileWriter("C:\\FileHandlingDemo\\File1.txt",true);
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the text : ");
		String name = s.nextLine();
		fw.write("\n");
		fw.write(name);
		fw.flush();
		fw.close();
		s.close();
		System.out.println("Data Inserted Successfully");
		System.out.println();		System.out.println("Reading data from file");
		FileReader fr = new FileReader("C:\\FileHandlingDemo\\File1.txt");
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		while(line!=null)
		{
			System.out.println(line);
			line=br.readLine();
		}
		br.close();
	}

}
