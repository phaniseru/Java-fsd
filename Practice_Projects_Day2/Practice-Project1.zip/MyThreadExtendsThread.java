package com.multithreading;
public class MyThreadExtendsThread extends Thread
{
 	public void run()
 	{
  		System.out.println("concurrent thread started running..");
}
 	public static void main( String args[] )
 	{
  		MyThreadExtendsThread mt = new  MyThreadExtendsThread();
  		mt.start();
 	}
}
