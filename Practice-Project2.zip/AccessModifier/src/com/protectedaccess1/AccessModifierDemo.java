package com.protectedaccess1;


import com.protectedaccess.ProtectedAccessModifier;

public class AccessModifierDemo extends ProtectedAccessModifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessModifierDemo pam = new AccessModifierDemo	();
		pam.display();

	}

}
