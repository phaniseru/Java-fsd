package com.protectedaccess;

public class ProtectedAccessModifier {
	protected void display()
	{
		//scope is any where in package and 
		//child class outside the package but 
		//we have to use child reference only
		System.out.println("***---Protected access modifier demo---***");
		
		
	}

}
