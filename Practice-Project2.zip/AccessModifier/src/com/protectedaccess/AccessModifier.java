package com.protectedaccess;

public class AccessModifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedAccessModifier pam = new ProtectedAccessModifier();
		pam.display();

	}

}
