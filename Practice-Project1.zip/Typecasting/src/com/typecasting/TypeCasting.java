package com.typecasting;

public class TypeCasting {

	public static void main(String[] args) {
//implicit typecasting
//byte->char->short->int->long->float->double
		char c='d';
		int i=c;
		System.out.println("--Implicit typecasting--");
		System.out.println("char to int "+i);
		long l=i;
		System.out.println("int to long "+l);
		float f=l;
		System.out.println("long to float "+f);
		double d=f;
		System.out.println("float to double "+d);
		System.out.println("--Explicit typecasting--");
		System.out.println();
		double d1=10.6;
		float f1=(float)d1;
		System.out.println("double to float "+f1);
		long l1=(long)f1;
		System.out.println("float to long "+l1);
		int i1=(int)l1;
		System.out.println("long to int "+i1);
		short s=(short)i1;
		System.out.println("int to short "+s);
		byte b=(byte)s;
		System.out.println("char to byte "+b);
		System.out.println();
		
		

	}

}
