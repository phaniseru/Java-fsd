/**
 * 
 */
/**
 * 
 */
module Typecasting {
}