package com.validateEmail;

import java.util.ArrayList;
import java.util.Scanner;

public class ValidateEmail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();
		al.add("abc@gmail.com");
		al.add("xyz@gmail.com");
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the Email Id");
		String email=s.nextLine().toLowerCase().trim();
		if(al.contains(email))
		{
			System.out.println("Email is found");
		}
		else
		{
			System.out.println("Email id not found");
		}
		s.close();

	}

}
