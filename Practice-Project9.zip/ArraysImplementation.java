package com.arrays;

import java.util.Scanner;

public class ArraysImplementation {
	public static void main(String[] args) {
		/*
		 * Arrays is used to store group of data of similar type types of arrays
		 * 1.Single Dimensional 
		 * 2.Multi-Dimensional 
		 * 3.Jagged Arrays
		 */

		//Single Dimensional
		/*
		 * Array Decleration <data-type>[] array_name = new <data-type>[Size_of_array];
		 */
		Scanner sc = new Scanner(System.in);

		System.out.println("Single Dimensional"); String[] arr1 = new String[5];

		for(int i=0;i<arr1.length;i++) 
		{
			System.out.println("Enter the String for "+(i+1)+" Location");
			arr1[i]=sc.nextLine();
		} 
		for(int i=0;i<arr1.length;i++)
		{
			System.out.println(arr1[i].toString());
		}

		//Multi_Dimensional System.out.println("Multi Dimensional");
		int[][] arr2 =new int[3][4]; 
		for(int i=0;i<arr2.length;i++) 
		{ 
			for(int j=0;j<arr2[i].length;j++) 
			{
				System.out.println("Enter the values for "+i+" "+j+" Location");
				arr2[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<arr2.length;i++)
		{ 
			for(int j=0;j<arr2[i].length;j++)
			{
				System.out.print(arr2[i][j]);
			}
			System.out.println(); 
		}

		System.out.println("Jagged array");


		int[][] arr3 = new int[3][];
		arr3[0]=new int[3];
		arr3[1]=new int[2];
		arr3[2]=new int[1];
		for(int i=0;i<arr3.length;i++)
		{
			for(int j=0;j<arr3[i].length;j++)
			{
				System.out.println("Enter the values for "+i+" "+j+" Location");
				arr3[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<arr3.length;i++)
		{
			for(int j=0;j<arr3[i].length;j++)
			{
				System.out.print(arr3[i][j]);
			}
			System.out.println();
		}




		sc.close();



	}
}