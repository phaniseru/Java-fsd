package com.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class CollectionsSetDemo {
public static void main(String[] args) {
	//Set demo Adding Characters to hash set
	HashSet<Character> s=new HashSet<Character>();
	s.add('a');
	s.add('b');
	s.add('c');
	System.out.println(s);
	Iterator<Character> itr=s.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next()+" ");
	}
	//LinkedHashset Demo
	LinkedHashSet<Integer> c=new LinkedHashSet<Integer>();
	c.add(23);
	c.add(24);
	c.add(25);
	System.out.println(c);
	//TreeSet
	TreeSet<String> d=new TreeSet<String>();
	d.add("phani");
	d.add("teja");
	d.add("kumar");
	System.out.println(d);
	
		
	
			
	
}
}
