package com.methods;

public class Methods {
/*
 * methods->1.static-->we can call directly within the same class/with class name
 * a.static methods with parameters
 * a.1.static methods with return type with parameters
 * a.2.static methods without return type with parameters
 * b.static methods without parameters
 * b.1.static methods with return type  without parameters
 * b.2.static methods without return type  without parameters
 * 2.Instance-->we can call by using object reference only 
 * a.1.Instance methods with return type with parameters
 * a.2.Instance methods without return type with parameters
 * b.Instance methods without parameters
 * b.1.Instance methods with return type  without parameters
 * b.2.Instance methods without return type  without parameters
 * 3.method Overloading
 */
//static methods without return and without  parameter demo
	static void stWorWop()
	{
		System.out.println("static methods without return and without  parameter");
	}
//static methods with return and without  parameter demo
	static String stWrWop()
	{
	return "static methods with return and without  parameter demo";
	}
//static methods without return and with parameter demo
	static void stWorWp(String name)
	{
		System.out.println("static methods without return and with parameter"+name);
	}
//static methods with return and with parameter demo
	static String stWrWp(String name)
	{
     return "static methods with return and with parameter"+name;
	}
	//Instance methods without return and without  parameter demo
		void itWorWop()
		{
			System.out.println("Instance methods without return and without  parameter");
		}
	//Instance methods with return and without  parameter demo
		 String itWrWop()
		{
		return "Instance methods with return and without  parameter demo";
		}
	//Instance methods without return and with parameter demo
		void itWorWp(String name)
		{
			System.out.println("Instance methods without return and with parameter"+name);
		}
	//Instance methods with return and with parameter demo
		 String itWrWp(String name)
		{
	     return "Instance methods with return and with parameter"+name;
		}

			//Method overloading demo	 
			 void addition()
			{
				int a=10;
				int b=20;
				System.out.println("Addition is : "+(a+b));
			}
			 void addition(int a,int b)
			{
				System.out.println("Addition is : "+(a+b));
			}
			public static void main(String[] args) {
				System.out.println("\n\t\t****Static Method Call****");
				stWorWop();//static method call
				String name=stWrWop();
				System.out.println(name);
				stWorWp("welocme");
				String name1=stWrWp("Welcome");
				System.out.println(name1);
				System.out.println("\n\t\t****Instance Method Call****");
				Methods md = new Methods();
				md.itWorWop();//Instance method call
				String r1=md.itWrWop();
				System.out.println(r1);
				md.itWorWp("welocme");
				String r2=md.itWrWp("Welcome");
				System.out.println(r2);
				System.out.println("\n\t\t****Method Overloading****");
				md.addition();
				md.addition(20,50);
			}


}
