package com.tax.calculation;

public class ExceptionClass extends Exception{
	String msg;

	public ExceptionClass(String msg) {
		super(msg);
		
	}

	
	

}
